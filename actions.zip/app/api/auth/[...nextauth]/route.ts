export { GET, POST } from "@/auth"
